#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"; cd "$SCRIPT_DIR"

VERSION="3.6.0"
WEB_FILES=(index.html sw.js manifest.json lang.js icon-192.png icon-512.png)

echo "=== Breeze Build v${VERSION} ==="
echo ""

copy_web() {
  local dst="$1"
  for f in "${WEB_FILES[@]}"; do
    [ -f "$f" ] && cp "$f" "$dst/" || { echo "✗ $f missing"; exit 1; }
  done
  echo "✓ Web files copied to $dst/"
}

case "${1:-help}" in
  validate)
    bash validate.sh
    ;;

  web)
    echo "[Web] Deploying to Cloudflare Pages..."
    wrangler pages deploy . --project-name=breeze
    ;;

  desktop)
    echo "[Desktop] Building all platforms..."
    cd desktop && npm ci
    copy_web .
    npx electron-builder --win --x64
    npx electron-builder --linux --x64
    echo "✓ Win+Linux in desktop/dist/"
    ;;

  win|windows)
    cd desktop && npm ci
    copy_web .
    npx electron-builder --win --x64
    ;;

  mac|macos)
    cd desktop && npm ci
    copy_web .
    npx electron-builder --mac --universal
    ;;

  linux)
    cd desktop && npm ci
    copy_web .
    npx electron-builder --linux --x64
    ;;

  android)
    echo "[Android] Building APK..."
    cd mobile
    npm ci
    chmod +x scripts/build-mobile.sh
    ./scripts/build-mobile.sh android "${2:-debug}"
    ;;

  ios)
    echo "[iOS] Syncing..."
    cd mobile
    npm ci
    chmod +x scripts/build-mobile.sh
    ./scripts/build-mobile.sh ios
    ;;

  clean)
    echo "[Clean]"
    rm -rf mobile/www mobile/android mobile/ios mobile/node_modules
    rm -rf desktop/dist desktop/node_modules
    echo "✓ Clean"
    ;;

  *)
    echo "Usage: ./build.sh <command>"
    echo ""
    echo "  validate   Run quality gates (35 checks)"
    echo "  web        Deploy to Cloudflare Pages"
    echo "  desktop    Build Win + Linux (Electron)"
    echo "  win        Build Windows only"
    echo "  mac        Build macOS only"
    echo "  linux      Build Linux only"
    echo "  android    Build APK [debug|release]"
    echo "  ios        Sync iOS (requires macOS + Xcode)"
    echo "  clean      Remove all build artifacts"
    ;;
esac
